
import json
import boto3


def lambda_handler(event, context):

    client = boto3.client('route53')

    # TEST UPDATING OTHER RECORDSETS IN CORRECT DOMAIN

    zone_id = 'Z05739232WBO20BEZE484'  # qinjie.com
    value = "aaaaa"
    record_names = ['test.qinjie.com', 'banned.qinjie.com']

    for record_name in record_names:
        print(f"Updating {record_name}")
        try:
            response = client.change_resource_record_sets(
                HostedZoneId=zone_id,
                ChangeBatch={
                    "Comment": f"Update TXT Fields {record_name}",
                    "Changes": [
                        {
                            "Action": "UPSERT",
                            "ResourceRecordSet": {
                                "Name": record_name,
                                "Type": "TXT",
                                "TTL": 180,
                                "ResourceRecords": [
                                    {
                                        "Value": f'"{value}"'
                                    },
                                ],
                            }
                        },
                    ]
                }
            )
            print(f"Success: {response}")
        except Exception as ex:
            print(f"Error: {ex}")
        print('+++++++++++++++++++++++++++++++++++++++')

    # TEST UPDATING RECORDSETS IN WRONG DOMAIN

    zone_id = 'Z04824712LR428SMYXA4A'  # zhang.com
    value = 'aaaaa'
    record_names = ['test.zhang.com', 'banned.zhang.com']

    for record_name in record_names:
        print(f"Updating {record_name}")
        try:
            response = client.change_resource_record_sets(
                HostedZoneId=zone_id,
                ChangeBatch={
                    "Comment": f"Update TXT Fields {record_name}",
                    "Changes": [
                        {
                            "Action": "UPSERT",
                            "ResourceRecordSet": {
                                "Name": record_name,
                                "Type": "TXT",
                                "TTL": 180,
                                "ResourceRecords": [
                                    {
                                        "Value": f'"{value}"'
                                    },
                                ],
                            }
                        },
                    ]
                }
            )
            print(f"Success: {response}")
        except Exception as ex:
            print(f"Error: {ex}")
        print('+++++++++++++++++++++++++++++++++++++++')

    return {
        'Message': "DONE"
    }
